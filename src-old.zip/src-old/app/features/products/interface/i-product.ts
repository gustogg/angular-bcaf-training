export interface IProduct {
    nama: string;
    description: string;
    harga: number;
    created: Date;
    pilihanWarna: string[];
    foto: string;
}

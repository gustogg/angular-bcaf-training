import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  nama: string = 'OHLINS TTX';
  harga: number = 65998500;
  created: Date = new Date();
  pilihanMotor: string[] = ['Vespa Primavera', 'Vespa Sprint', 'Vespa LX-125'];
  foto: string = '29caf845-2baf-48fb-a341-1e47b1c3ca91.jpg';
  foto2: string = '73cbc97a-dc41-43f2-ac75-ef992fa26dc0.jpg';


  getPajak(persentase: number, hargaAfterDiskon: number): number {
    return hargaAfterDiskon + this.harga * persentase;
  }
}

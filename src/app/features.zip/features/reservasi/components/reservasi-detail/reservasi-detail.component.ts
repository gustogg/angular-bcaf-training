import { Component } from '@angular/core';

@Component({
  selector: 'app-reservasi-detail',
  templateUrl: './reservasi-detail.component.html',
  styleUrl: './reservasi-detail.component.css'
})
export class ReservasiDetailComponent {

}

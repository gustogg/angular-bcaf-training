import { Component } from '@angular/core';

@Component({
  selector: 'app-reservasi-list',
  templateUrl: './reservasi-list.component.html',
  styleUrl: './reservasi-list.component.css'
})
export class ReservasiListComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-reservasi-search',
  templateUrl: './reservasi-search.component.html',
  styleUrl: './reservasi-search.component.css'
})
export class ReservasiSearchComponent {

}

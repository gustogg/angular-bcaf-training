import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-choice',
  templateUrl: './customer-choice.component.html',
  styleUrl: './customer-choice.component.css'
})
export class CustomerChoiceComponent {

}

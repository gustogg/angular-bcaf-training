export interface ITodo {
  id: number;
  task: string;
  isDone: boolean;
}

export interface IVariant {
  key: string;
  value: string | number;
  picture: string;
}
